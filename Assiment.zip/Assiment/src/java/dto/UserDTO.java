/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author hoang
 */
public class UserDTO {
    private String UserName ;
    private String Password ;
    private int Type ;
    private int Id ;

    public UserDTO() {
        this.Type = 2 ;
    }

    public UserDTO( int Id ,String UserName, String Password, int Type ) {
        this.Id = Id;
        this.UserName = UserName;
        this.Password = Password;
        this.Type = Type;
        
    }
    public String getUserName() {
        return UserName;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public int getType() {
        return Type;
    }

    public void setType(int Type) {
        this.Type = Type;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    @Override
    public String toString() {
        return "UserType{" + "UserName=" + UserName + ", Password=" + Password + ", Type=" + Type + '}';
    }
    
}

