/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import dao.UserDAO;
import dto.UserDTO;

/**
 *
 * @author hoang
 */
public class userTesst {
      public static void main(String[] args) {
        UserDAO user = new UserDAO();
        UserDTO u2 = new UserDTO(1,"nam","123",1);
        user.update(u2);
//        user.deleteByUserName("phi");
//        user.deleteByUserName("Nam2");
     
    }
}
